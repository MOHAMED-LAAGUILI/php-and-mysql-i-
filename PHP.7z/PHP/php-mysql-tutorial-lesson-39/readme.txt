Be yourself; everyone else is already taken.
We are all in the gutter, but some of us are looking at the stars.
To live is the rarest thing in the world. Most people exist, that is all.
I can resist everything except temptation.
The truth is rarely pure and never simple.
Life is too important to be taken seriously.