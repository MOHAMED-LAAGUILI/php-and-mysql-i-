<?php 

	$ninjas = ['shaun', 'ryu', 'yoshi'];

	echo $ninjas[1] . '<br />';

?>