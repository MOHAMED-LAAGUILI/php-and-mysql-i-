<?php 

	//include('ninjass.php');
	
	//require('ninjass.php');

	//include 'ninjas.php';

	//require 'ninjas.php';

	//echo 'end of php';

?>

<!DOCTYPE html>
<html>
<head>
	<title>PHP Tutorials</title>
</head>
<body>

	<?php include('content.php'); ?>
	<?php include('content.php'); ?>

</body>
</html>