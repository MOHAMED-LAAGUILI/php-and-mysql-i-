<?php
$Username = "root";
$Password = "";
$Database = "formdb";


if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])){

    $con = mysqli_connect('localhost',$Username,$Password,$Database) or die('Connection failed'.mysqli_connect_error());

    if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['bgroup'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $bgroup = $_POST['bgroup'];

        $sql = "INSERT INTO `users` (`name`,`email`,`phone`,`bgroup`) VALUES('$name', '$email', '$phone', '$bgroup')";
        $query = mysqli_query($con,$sql);

        if($query){
            echo "Entry Successfull";
        }else{
            echo "Error: ".mysqli_error();  
        }
    }
}

?>