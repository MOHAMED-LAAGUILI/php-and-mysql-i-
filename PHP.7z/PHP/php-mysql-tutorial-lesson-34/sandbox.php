<?php 

	// ternary operators

	$score = 50;

	// if($score > 40){
	// 	echo 'high score!';
	// } else {
	// 	echo 'low score!';
	// }

	// echo $score > 40 ? 'high score!' : 'low score!';

?>

<!DOCTYPE html>
<html>
<head>
	<title>php tuts</title>
</head>
<body>

	<h2><?php echo $score > 40 ? 'high score!' : 'low score!'; ?></h2>

</body>
</html>