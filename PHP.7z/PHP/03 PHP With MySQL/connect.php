<?php

$username = "root";
$password = "";
$database = new PDO ("mysql:host=localhost;dbname=codeshiyar;charset=utf8;",$username,$password);

if ($database){
    echo 'Connection established';
}
?>