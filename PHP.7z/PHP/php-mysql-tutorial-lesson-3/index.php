<?php 

	// echo 'hello, ninjas';

?>

<!DOCTYPE html>
<html>
<head>
	<title>my first PHP file</title>
</head>
<body>
	<h1><?php echo 'hello, ninjas' ?></h1>
</body>
</html>