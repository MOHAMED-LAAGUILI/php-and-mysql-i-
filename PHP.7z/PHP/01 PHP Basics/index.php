<?php 
// phpinfo(); all the info u want to know
echo gettype(true); // boolean
echo '<br>';
echo gettype(true); // boolean
echo '<br>';
echo gettype(100); // integer
echo '<br>';
echo gettype(70.5); // Double / float
echo '<br>';
echo gettype('true'); // String
echo '<br>';
echo gettype(array('EG' => 'Egypt', 'US' => 'UUnited States')); // array
echo '<br>';
echo '<hr>';



///////////////////////////////////////////////////////////////
/////////////////////////// Casting///////////////////////////
/////////////////////////////////////////////////////////////
echo gettype(100 + (int)"50 copy"); // integer
echo '<br>';
echo gettype((int) 100.5 + (int) 100.5); // integer = 200
echo '<br>';
echo (int) 100.5 + (int) 100.5; // integer = 200
echo '<br>';
echo (int) (100.5 + 100.5); // integer = 201
echo '<hr>';



///////////////////////////////////////////////////////////////
/////////////////////////// Data Type///////////////////////////
/////////////////////string and escaping///////////////////////
/////////////////////////////////////////////////////////////

$name = 'mohamed';

echo "<ul>";
    echo "<li>". $name ."</li> ";
    echo  "<li>". $name . "</li>";
    echo  "<li>" . $name ."</li>";
echo "</ul>";


echo  <<< "navlink"
<ul>
    <li> $name </li>
    <li> $name </li>
    <li> $name </li>
</ul>
navlink;

//// print_r is used to print array elements
 echo '<pre>';
print_r([
    0 => "Mohamed",
    1 => "Mohamed",
    2 => "mohamed",
    3 => "mohamed",
]);
echo '</pre>';



?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        welcome 
        <?php
        echo $name;
        ?>
    </title>
 </head>
 <body>
    <div>
    <?php
        echo $name;
        ?>
        you have scored 1000 points
    </div>

 <?php
        include("score.php");
        ?>
   
 </body>
 </html>

 <?php
 echo '<hr>';
$a = "ossama";
$$a = "zero";
$$$a = "school";

echo '<br>';
echo $a;
echo '<br>';
echo $$a;
echo '<br>';
echo $$$a;
echo '<br>';

echo "Hello ${$$a}"; // $$$a
echo '<hr>';



/*
Assign Variable by referece
by default variables are assigned by value
Assigned by referece make variable alias or point to another
*/

$b = "Osama";
$c = &$b;
$c = "Zeroes";
$b = "school";

echo '<br>';
echo $b;
echo '<br>';
echo $c;
echo '<br>';
echo '<hr>';


/*
Predefined Variables
*/

echo '<pre>';
    //print_r($_SERVER);
    echo $_SERVER["HTTP_CONNECTION"];
echo '</pre>';

    echo $_POST["username"];


 ?>

 <form action="" method="POST">
    <input type="text" name="username">
    <input type="submit" value="Send">
 </form>
<hr>
<?php 

/*
Constant variables
*/

define("TVA", 0.2);
// define("TVA", 0.5); you can define a constant more than once
echo TVA;
echo '<hr>';

/*
Pre-defined constant [Case Sensitive]
PHP_VERSION
PHP_OS_FAMILY
PHP_INT_MAX
DEFAULT_INCLUD_PATH

magic Constant [Case Insnesitive]
__LINE__
__FILE__
__DIR__

Reserved Keyword
break
clone
*/
echo php_uname(); // Windows NT DESKTOP-3H1AUU6 10.0 build 19044 (Windows 10) AMD64
echo '<br>';
echo PHP_VERSION; // 8.1.6
echo '<br>';
echo __LINE__; // 186
echo '<br>';
echo __FILE__; // C:\xampp\htdocs\PHP\index.php
echo '<br>';
echo __DIR__; // C:\xampp\htdocs\PHP
echo '<br>';



/*
Comparaison Operators
part 1:

==  equal (only need same value)
!=  not equal
<>  not equal
=== identical (needs same value and same type)
!== not identical
*/

var_dump(100 == 100); // true
echo '<br>';
var_dump(100 == "100"); // true
echo '<br>';
var_dump(100 != "100"); // false
echo '<br>';
var_dump(100 <> "100"); // false
echo '<br>';
var_dump(100 === "100"); // false
echo '<br>';
var_dump(100 == 100); // true
echo '<br>';
echo '##############################';
echo '<br>';
var_dump(100 === 100); // true
echo '<br>';
var_dump(100 === "100"); // false
echo '<br>';
var_dump(100 !== "100"); // false
echo '<br>';
var_dump(100 <> "100"); // false
echo '<br>';
var_dump(100 === "100"); // false
echo '<br>';
var_dump(100 !== "100"); // true
echo '<br>';
var_dump(100.0 !== 100); // true
echo '<br>';



/*
Comparaison Operators
part 2:

>   larger than
>=  larger than or equal
<   smaller than
<=  smaller than or equal
<=> spaceship [less than, Equal or Greater]
*/

var_dump(100 > 50);
echo '<br>';
var_dump(100 >= 50);
echo '<br>';
var_dump(100 < 50);
echo '<br>';
var_dump(100 <= 50);
echo '<br>';
var_dump(100 <=> 200); // -1 less than
echo '<br>';
var_dump(100 <=> 100); // 0 equal
echo '<br>';
var_dump(100 <=> 50); // 1 greater
echo '<br>';



/*
Increment & Decrement Operators;
increment
a++;
pre increment
++a;
dencrement
a--;
pre dencrement
--a;
*/

$likes = 0;
$likes++; // 1
$likes++; // 2
$likes++; // 3
$likes--; // 2
echo $likes; // 2
echo '<br>';

$followers = 0;
$followers--; // -1
$followers--; // -2
echo $followers; // -2
echo '<br>';



/*
String Operators output
. concatinate
.= concatinate
*/
define("Dev", "Mohamed");

function test()
{
    return 1;
}

$var1 = "Ossama";
$var2 = "Elzero";
$var3 = "School";

echo "$var1 $var2 $var3";
echo '<br>';
echo "{$var1} {$var2} {$var3}";
echo '<br>';
echo $var1 . " " . $var2 . " " . $var3;
echo '<br>';
echo "{$var1} {$var2} {$var3} " . Dev . " " . Test();
echo '<br>';

$var1 = "Ossama";
$var2 .= "Elzero"; // var2 = Ossama + Elzero = Osama Elzero
$var3 .= "School"; // var3 = Osama Elzero + School



/*
Operators in array

+   Union
==  equal (same key & same value)
!=  not equal
<>  not equal
=== identical (same key & value & order & type)
!== not identical
*/

$arr1 = [1=>"A", 2=>"B"];
$arr2 = [3=>"C", 4=>"D"];
$arr3 = $arr1 + $arr2;

echo '<pre>';
print_r($arr1 + $arr2);
print_r($arr3);
echo '</pre>';


$arr4 = [1 => "10", 2 => "20"];
$arr5 = [2 => 20, 1 => 10];

var_dump($arr4 == $arr5); // true
echo '<br>';
var_dump($arr4 != $arr5); // false
echo '<br>';
var_dump($arr4 <> $arr5); // false
echo '<br>';


$arr6 = [1 => 100, 2 => 200];
$arr7 = [2 => 200, 1 => 100];

var_dump($arr6 === $arr7); // true
echo '<br>';



/*
Error handling

@  (to hide error message)
or die("message") // (if the value is not exists this to show a message instead the error but it quit the php file)
File
Include
*/

$ze= 10;
$wx = @$ze or die("Value Empty");

echo "test $wx";
echo '<br>';

// File
$f =  @File("moha.txt");
print_r($f);

//Include
@include("moha.php") or die("Include file not found");




/*
Operators
Used To Perform Operations On Values.

Operator Precedence
||   Has A Greater Precedence Than "or"
&&   Has A Greater Precedence Than "and"
*/
echo 2 + 4 * 5; // 22
echo '<br>';
echo (2 + 4) *.5; //-30
echo '<br>';
echo 10 || false; // 1 = true
echo '<br>';
echo 10 || false || 0 || [] || ""; //-True =>-1
echo '<br>';
echo true; //-1
echo '<br>';
var_dump(10 || false || 0 || [] || ""); // True
echo '<br>';
echo 10 || false; // 1
echo '<br>';
$v02 = 10 || false; // $v02 = (10 || false) => $v02 = 1
echo $v02; // 1
echo '<br>';
$v03 = 10 or false; // ($v03 = 10) or false
echo $v03; // 10
echo '<br>';


/*
Control Structure
If, Elseif, Else <= Basics

.. Syntax
if (Condition) {
// If Condition Is True <= Run-Me
} else {
//I -Condition Is False <= Run-Me
}
*/

// 30%

if (10 > 10){
echo "First Condition";
} elseif(10 > 10){
echo "Second Condition";
} else{
echo "No";
}

echo '<br>';

$lang = "Spanish";
if ($lang == "Arabic") {
echo 'marhaba hhhh';
} elseif($lang == "English") {
echo 'Hello';
} elseif ($lang == "Spanish") {
echo 'Hola';
} else {
echo "Unknown Language";
}
echo '<br>';

?>




<?php
/*
Control Structure
If, Elseif, Else <= Advance practice
60%
*/



if (@$_SERVER["REQUEST_METHOD"] === "POST") {
if (@$_POST["lang"] == 'ar') {
        header("location: ArSupport.php");
        exit();
}elseif (@$_POST["lang"] == 'en') {
            header("location: EnSupport.php");
            exit();
    }elseif (@$_POST["lang"] == 'sp') {
        header("location: SpSupport.php");
        exit();
}
    
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support</title>
</head>
<body>
    <form action="" method="POST">
        <input type="text" name="username">
        <select name="lang">
            <option value="ar">Arabic</option>
            <option value="en">English</option>
            <option value="sp">Spanish</option>
            <input type="submit" value="Go">
        </select>
    </form>
    
</body>
</html>




<?php
/*
Control Structure
If, Elseif, Else <= Alternative Syntax
80%
methode 1
*/
if (10 >= 10){ 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
Hello World 1
</body>
</html>

<?php } ?>


<?php
/*
Control Structure
If, Elseif, Else <= Alternative Syntax
80%
methode 2
*/
if (10 >= 10) : ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <br>
        Hello World 2
    <br>
</body>
</html>

<?php endif; ?>



<?php
/*
Control Structure
If, Elseif, Else <= Alternative Syntax
80%
methode 3
*/
if (10 > 10) :
    echo "One";
elseif(10 > 5) :
    echo "Two";
else :
    echo "Three";
endif;
echo '<br>';


/*
Condition ? true : false ;
*/

//methode 4-1
echo "I love PHP because its a ". (10 >= 10 ? "Good" : "Bad"). " Language";
echo '<br>';

// methode 4-2
$result =  10 >= 10 ? "Good" : "Bad";
echo "I love PHP because its a $result Language";
echo '<br>';



/*
Control Structure
Switch()
*/

$Day = "Sunday";

switch ($Day){
    case "Monday":
        echo "Monday";
        break;
    case "Tuesday":
        echo "Tuesday";
        break;
    case "Wednesday":
        echo "Wednesday";
        break;
    case "Thursday":
        echo "Thursday";
        break;
    case "Friday":
        echo "Friday";
        break;
    case "Saturday":
    case "Sunday":
        echo "Holiday Week-end We are Off";
        break;
    default:
    echo "Unknown Day";
}




/*
Control Structure
While loop
*/

//Methode 1
$varx = 0;
while($varx <= 8) {
    echo "I love PHP $varx";
    echo '<br>';
    $varx++;
}

// Methode 2
$a = 1;
while($a <= 8) :
    echo "I love PHP in while loop $a";
    echo '<br>';
    $a++;
endwhile;




/*
Control Structure
Do While loop
*/

$vardo = 1;
do{
    echo "I love PHP in do while loop $vardo";
    echo '<br>';
    $vardo++;
}while($vardo < 8);




/*
Control Structure
for loop
*/

//method 1
for($varf = 0+1; $varf <= 8; $varf++) {
    echo "I love PHP in for loop $varf ";
    echo '<br>';
}

//method 2
for($varf = 0+1; $varf <= 8; $varf++) :
    echo "I love PHP in for loop $varf ";
    echo '<br>';
endfor;




/*
Control Structure
foreach loop
*/


$Countries = ["Eg", "Sa","Ma","Sy"];

echo '<pre>';
print_r($Countries);
echo '</pre>';
echo '<br>';

foreach ($Countries as $Country) {
    echo $Country;
    echo '<br>';
}

$Countries_Discount = ["Eg" => 50 ,"Sa" => 60 ,"Ma" => 80 , "Sy" => 90 ];

echo '<pre>';
print_r($Countries_Discount);
echo '</pre>';
echo '<br>';

///// method 1
foreach ($Countries_Discount as $Country => $Discount) {
    echo "Country name is $Country and discount is $Discount";
    echo '<br>';
}

echo '<hr>';

/////  method 2
foreach ($Countries_Discount as $Country => $Discount) :
    echo "Country name is $Country and discount is $Discount";
    echo '<br>';
endforeach;



/*
Control Structure
Incluging Files
*/
// include => it include a file if not exit it shows a warning message
// include_once => it same definition above but it used one time
// Require => same as include but if the file is not found it exit the script like Die() func
// require_once => it same definition above but it used one time

// include
include("moha.php");
echo " continue";
echo '<br>';

// Require
require("moha.php");
echo " continue";
echo '<br>';




/*
Fonctions
Intrudoction to DRY Concept (Dont Repeat Yourself)
Prameter
Argument
*/


function Say_Hello_To($name, $last){
    echo "Hello Mr. $name $last <br>";
}

Say_Hello_To("Mohamed","Laaguili");
Say_Hello_To("Ossama", "Elzero");
Say_Hello_To("Ahmad", "Edoukhi");
 



/*
Fonctions
Advanced Practice 
*/


function Deep_Freez($item){
    if($item === "Water"){
        echo "Make it ice <br>";
    }elseif($item === "Coca Cola"){
        echo "Make it cold <br>";
    }elseif($item === "Fruits"){
        echo "Make it fresh <br>";
    }else{
        echo "Unknow Item <br>";
    }
}

Deep_Freez("Fruits");
Deep_Freez("Tv");
Deep_Freez("Coca Cola");
Deep_Freez("Water");




/*
Fonctions
Advanced Practice
Optional Return
End after return
*/

$prizes = ["PC", "PlaySation 4", "Apple TV", "Ipad", "Iphone"];

function get_number($num_one, $num_two){
    return $num_one + $num_two;
    // any thing after return wont print out 
}

echo $prizes[get_number(1, 2)];
echo '<br>';
echo $prizes[3]; // same thing
echo '<br>';





/*
Fonctions
Advanced Practice
Default Parameter
*/


function get_data($FullName, $Age, $Country, $Address = "Unknown Address"){
    // the default only used in the last one or all 
    $line_one = "Hi $FullName your age is $Age and your country is $Country <br>";
    $line_two = "And your Address is $Address";
    return $line_one . $line_two;
}

/////Methode 1
echo get_data("Mohamed Laaguili", 21, "Maroc"); 
// if the user didnt add a value to argument it takes a default value in function parameter

//////Methode 2
// echo get_data(FullName: "Said");
// it wont work due to you already name that parameter in the argument
// with mohamed laaguili above in line 834





/*
Fonctions
Advanced Practice
Spread Parameter
*/

function Calculate(...$num){
    // ... the 3 dot it let you add as many as you want of argument in declaration
    echo "Argument of index 3 is ". $num[3]. "<br>";
    print_r($num);
    $result = 0;
    foreach($num as $num) :
        $result +=$num;
    endforeach;
    echo "<br>";
    echo $result;
}

Calculate(10, 50, 30, 40); // 130
echo "<br>";



/*
Fonctions
Advanced Practice
Variable function
Check Fuction is Exist or not
// String length (strlen)
// Return type of declaration
*/

function one(){
    return"One from function";
}
// Variable function
$function_var = "one";

echo $function_var(); // same as echo one();
echo "<br>";

//Check Fuction is Exist or not
if(function_exists("one")){
    echo one();
    echo "<br>";
}else{
    echo "Function not found";
    echo "<br>";
}

// String length (strlen)
echo strlen("Laaguili");
echo "<br>";

// Return type of declaration
function numbers($n1, $n2) : int{ // return type of declaration is int
    return $n1 + $n2;
}

echo numbers(10.5, 56.6); // Return integet value





/*
Fonctions
  - Anonymous function
    // function with out name
  - Variable inhert from parent scope
  - Variable inhert by reference from parent scope
  - Anonymous function can be passed to a function
  - Anonymous function can be return from a function
*/


// normal function with parameter
function say_hi($someone){
    return "hello $someone";
}
echo say_hi("mohamed");
echo "<br>";

// Anonymous function in variable
$say_hola = function(){
    return "hello";
};

echo $say_hola();
echo "<br>";

// Anonymous function with parameter in variable
$say_hello = function($person){
    return "hello $person";
};

echo $say_hello("Laaguili");
echo "<br>";

// Inherit variable from parent
$msg = "hi";
$say_hi = function($person) use ($msg){
    return "$msg $person";
};

echo say_hi("MOHA");
echo "<br>";

// Pass anonymous function to function => array_map
// method 1
$arrnum =[10 , 20, 30, 40, 50];
function add_five($items){
    return $items + 5;
}

$nums_after_adding_five = array_map("add_five",$arrnum);
echo '<pre>';
print_r($nums_after_adding_five);
echo '</pre>';

// method 2
$nums_after_adding_ten = array_map(function($items){ return $items + 10;},$arrnum);
echo '<pre>';
print_r($nums_after_adding_ten);
echo '</pre>';



/*
Fonctions
  - Arrow Functions
  Short syntax function replaced with fn
  removed curly brackets and returned function
  add all in one line
*/


// Arrow  function in variable
$say_hola = fn() => "hello";


echo $say_hola();
echo "<br>";

// Arrow function with parameter in variable
$say_hello = fn($person) => "hello $person";

echo $say_hello("Laaguili");
echo "<br>";

// Arrow Inherit variable from parent
$msg = "hi";
$say_hi = fn($person) => "$msg $person";


echo say_hi("MOHA");
echo "<br>";

// Pass Arrow function to function => array_map
// method 1
$arrnum =[10 , 20, 30, 40, 50];
$nums_after_adding_ten = array_map(fn($items) => $items + 10 , $arrnum);
echo '<pre>';
print_r($nums_after_adding_ten);
echo '</pre>';
echo "<br>";



/*
String
    Access element
    access elements by index
    negative index values are allowed
Update elements
    Update current element
    Add new element
*/
$str = 'Mohamed';

// access elements by index
echo $str[0]; // M Cause it index and start from 0
echo "<br>";
echo strlen($str); // 7 cause it start from 1
echo "<br>";
// negative index values are allowed
echo $str[-1]; // last element d
echo "<br>";
// Update current element
$str[-2] = "a"; // o to a
echo "<br>";
echo $str; // Mohamad
// Add new element
$str[7] = "e";
echo "<br>";
echo $str; // Mohamade
echo "<br>";

/*
String Functions
    lcfirst(string[required])
    ucfirst(string[required])
    strtolower(string[required])
    strtoupper(string[required])
    ucwords(string[required])
    str_repeat(string[required], count[required])
*/

echo lcfirst("Mohamed Laaguili") . '<br>'; // mohamed Laaguili first case lower
echo ucfirst("mohamed laaguili") . '<br>'; // Mohamed laaguili first case upper
echo strtolower("MOHAMED Laaguili") . '<br>'; // mohamed laaguili all string to lower case
echo strtoupper("mohamed Laaguili") . '<br>'; // MOHAMED LAAGUILI all string to upper
echo ucwords("Mohamed Laaguili") . '<br>'; // Mohamed Laaguili first string in each to upper case
echo ucwords("Mohamed Laaguili School", "") . '<br>'; // Mohamed Laaguili first string in each to upper
echo str_repeat("Mohamed", 3) . '<br>'; // mohamed mohamed mohamed





/*
String Functions
    implode(separator[required], Array[required]) join() is alias
    explode(separator[required], string[required], limit[optional])
    str_shuffle(string[required])
    strrev(string[required])
    trim(string[required], charslist[Optional])
    ltrim(string[required], charslist[Optional])
    rtrim(string[required], charslist[Optional])
*/

// implode(separator[required], Array[required]) join() is alias
$friends = ["mohamed", "reda", "adam"];
echo implode(" ", $friends) . '<br>'; // mohamed reda adam
echo implode(", ", $friends) . '<br>'; // mohamed, reda, adam
echo implode("@", $friends) . '<br>'; // mohamed@reda@adam
echo implode($friends) . '<br>'; // mohamedredaadam

// explodeseparator[required], string[required], limit[optional])
$strex = "Elzero Web School is cool";
echo'<pre>';
print_r(explode(" ", $strex));
echo'</pre>';
/*
    [0] => Elzero
    [1] => Web
    [2] => School
    [3] => is
    [4] => cool
*/

echo'<pre>';
print_r(explode("i", $strex));
echo'</pre>';
/*
    [0] => Elzero Web School 
    [1] => s cool
*/

echo'<pre>';
print_r(explode(" ", $strex, 2));
echo'</pre>';
/*
  [0] => Elzero
  [1] => Web School is cool
*/

// str_shuffle(string[required])
echo str_shuffle("MOHAMED");

// trim(string[required], charslist[Optional])
echo strlen("   Elzero   ") . '<br>'; // 12
echo strlen(trim("   Elzero   ")) . '<br>'; // 6
echo trim("   Elzero   ", " ") . '<br>'; // Elzero




/*
String Functions
    chunk_split(string[required], length[optional], end[optional])
    strlen(string[required])
    str_split(string[required], length[optional])
    strip_tags(string[required], allowed[optional])
    nl2br(string[required], XHTML[optional])
    
*/ 

echo chunk_split("Elzero Web School is cool", 3, "@") . '<br>';  // Elz@ero@ We@b S@cho@ol @is @coo@l@

echo '<pre>';
print_r(str_split("Elzero")) . '<br>';
echo '</pre>';
/*
    [0] => E
    [1] => l
    [2] => z
    [3] => e
    [4] => r
    [5] => o
*/

echo '<pre>';
print_r(str_split("Elzero", 2)) . '<br>';
echo '</pre>';
/*
    [0] => El
    [1] => ze
    [2] => ro
*/

$oldtxt = "Hello World!";
echo '<br>';
$newtxt = str_replace("World", "Dolly", $oldtxt);
echo $newtxt; // Dolly World
echo '<br>';
echo "<h3> Hello <b> World <b> </h3>". '<br>' ;
echo '<br>';
echo strip_tags("<h3> Hello <b> World <b> </h3>"); //strip tags cancel the tags attribute
echo '<br>';
echo strip_tags("<h3> Hello <b> World <b> </h3>", "<b>, <h3>" );
echo '<br>';
echo nl2br("Elzero \n Web \n School");
echo '<br>';




/*
String Function
    strpos(String[required], Value[required], start potision[optional]) => Case sensitive
    strrpos(String[required], Value[required], start potision[optional]) => Case sensitive
    stripos(String[required], Value[required], start potision[optional]) => Case insensitive
    strripos(String[required], Value[required], start potision[optional]) => Case insensitive
    substr_count(String[required], Value[required], start potision[optional], length[optional]) => case sensitive
*/

// strpos
var_dump(strpos("Hello Hello", "H")); // 0
echo '<br>';
var_dump(strpos("Hello Hello", "H", 3)); // 6
echo '<br>';
var_dump(strpos("Hello Hello", "H", 6)); // 6
echo '<br>';
var_dump(strpos("Hello Hello", "h", 6)); // false
echo '<br>';
var_dump(strpos("Hello Hello", "h", -2)); // false => it goes from the the left to right
echo '<br>';

// strrpos
// its start index from left but it take the last right string
var_dump(strrpos("Hello Hello", "H", -11)); // 0
echo '<br>';
var_dump(strrpos("Hello Hello", "H", 5)); // 6
echo '<br>';

// stripos
//  the only deffrence betwen strpos & stripos . 
//  strpos case sensitive
//  stripos case insensitive
var_dump(stripos("Hello Hello", "h", 6)); // 6
echo '<br>';

// strripos
//  the only deffrence betwen strrpos & strripos . 
//  strpos case sensitive
//  stripos case insensitive
// its start index from left but it take the last right string
var_dump(stripos("Hello Hello", "h")); // 0
echo '<br>';

// substr_count => case sensitive
var_dump(substr_count("Hello Hello", "He")); // 2 is many times "He" repeated
echo '<br>';
var_dump(substr_count("Hello Hello", "He", 2)); // 1 cause is passed the first repeat
echo '<br>';
var_dump(substr_count("Hello Hello", "He", 2, 4)); // 0 cause its not in 2 & 4 index zone
echo '<br>';





/*
String function
    parse_str(string[required], array[required])
    quotemeta(string[required])
    str_pad(string[required],length[required], string[optional], pad flag[optional]) => pad = padding
        STR_PAD_BOTH
        STR_PAD_LEFT
        STR_PAD_RIGHT
    strtr(string[required], from[required], to[required]) || strtr(string[required], array[required])
*/

// parse_str
parse_str("FName=Mohamed&LName=Laaguili&OS=Windows 10", $Query);

echo "<pre>";
print_r($Query);
echo "</pre>";

echo $Query["FName"] . "<br>";
echo $Query["LName"] . "<br>";
echo $Query["OS"] . "<br>";

// quotemeta
echo "Hello [] () * + . <br>";
echo quotemeta("Hello [] () * + . <br>");

// str_pad => padding
echo "12" . "<br>";
echo "123" . "<br>";
echo "1234" . "<br>";
echo "12345" . "<br>";
echo "123456" . "<br>";

echo str_pad("12",8) . "<br>"; // if dont add the a value it takes spaces by default
echo str_pad("123",8) . "<br>";
echo str_pad("1234",8) . "<br>";
echo str_pad("12345",8) . "<br>";
echo str_pad("123456",8) . "<br>";

echo str_pad("12", 8, 0, STR_PAD_BOTH) . "<br>";
echo str_pad("123", 8, 0, STR_PAD_BOTH) . "<br>";
echo str_pad("1234", 8, 0, STR_PAD_LEFT) . "<br>";
echo str_pad("12345", 8, 0, STR_PAD_RIGHT) . "<br>";

// strtr => string translate
// method 1 => whene we want to change one char
echo strtr("E@zero Web Schoo@ is coo@", "@", "l");
echo "<br>";

// method 2 => whene we want to change more than one char we use an array
$trans = ["@" => "l", "#" => "o"];
echo strtr("E@zer# Web Sch##@ is c##@",$trans);
echo "<br>";




/*
String function
    str_replace(Find[required], Replace with[required], string[required], replace count[required])
        case sensitive
    str_ireplace(Find[required], Replace with[required], string[required], replace count[required])
        case insensitive
*/

// str_replace
// method 1
echo str_replace("@" , "l", "E@zero Web Schoo@ is coo@", $rc);
echo "<br>";
echo "replace count is $rc";
echo "<br>";
// method 2
echo str_replace(["#", "@"], ["o", "l"], "E@zer# Web Sch##@ is c##@");
echo "<br>";
// method 3
echo "<pre>";
print_r(str_replace("one", 1, ["one", "two", "one"]));
echo "</pre>";
echo "<br>";
// method 4
echo "<pre>";
print_r(str_replace(["one", "two"], [1, 2], ["one", "two", "three"]));
echo "</pre>";
echo "<br>";

// str_ireplace => insensitive replace
echo "<pre>";
print_r(str_ireplace(["ONE", "TWO"], [1, 2], ["one", "two", "three"]));
echo "</pre>";
echo "<br>";


















?>
