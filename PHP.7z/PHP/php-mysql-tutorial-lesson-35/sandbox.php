<?php 

	// superglobals

	//$_GET['name'], $_POST['name']

	echo $_SERVER['SERVER_NAME'] . '<br />';
	echo $_SERVER['REQUEST_METHOD'] . '<br />';
	echo $_SERVER['SCRIPT_FILENAME'] . '<br />';
	echo $_SERVER['PHP_SELF'] . '<br />';

	// $_COOKIE, $_SESSION


?>

<!DOCTYPE html>
<html>
<head>
	<title>php tuts</title>
</head>
<body>

</body>
</html>